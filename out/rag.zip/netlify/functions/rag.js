var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var rag_exports = {};
__export(rag_exports, {
  chatAboutPdf: () => chatAboutPdf,
  ensureIndexForDoc: () => ensureIndexForDoc,
  getDocPages: () => getDocPages
});
module.exports = __toCommonJS(rag_exports);
var fs = __toESM(require("fs"), 1);
var import_node_fs = require("node:fs");
var import_node_path = __toESM(require("node:path"), 1);
var import_pdf_parse = __toESM(require("pdf-parse"), 1);
var import_llamaindex = require("llamaindex");
var import_huggingface = require("@llamaindex/huggingface");
var import_genai = require("@google/genai");
var import_dotenv = __toESM(require("dotenv"), 1);
const pdf = import_pdf_parse.default;
import_dotenv.default.config();
import_llamaindex.Settings.embedModel = new import_huggingface.HuggingFaceEmbedding({ model: "Xenova/all-MiniLM-L6-v2" });
const ai = new import_genai.GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY
});
import_llamaindex.Settings.chunkSize = 900;
import_llamaindex.Settings.chunkOverlap = 150;
const dataDir = import_node_path.default.join(process.cwd(), "data");
async function ensureIndexForDoc({ docId, filePath }) {
  try {
    const persistDir = import_node_path.default.join(dataDir, docId);
    await import_node_fs.promises.mkdir(persistDir, { recursive: true });
    const fileBuffer = await import_node_fs.promises.readFile(filePath);
    const pdfData = await pdf(fileBuffer);
    if (!pdfData.text || pdfData.text.trim().length === 0) {
      throw new Error("No text could be extracted from the PDF");
    }
    const doc = new import_llamaindex.Document({ text: pdfData.text, metadata: { source: filePath } });
    const storageContext = await (0, import_llamaindex.storageContextFromDefaults)({ persistDir });
    const index = await import_llamaindex.VectorStoreIndex.fromDocuments([doc], { storageContext });
    const numPages = pdfData.numpages || 1;
    const manifest = {
      pageCount: numPages,
      pages: Array.from({ length: numPages }, (_, i) => ({ page: i + 1 }))
    };
    await import_node_fs.promises.writeFile(import_node_path.default.join(persistDir, "pages.json"), JSON.stringify(manifest));
    return index;
  } catch (error) {
    console.error("Error in ensureIndexForDoc:", error);
    throw error;
  }
}
async function chatAboutPdf({ docId, message }) {
  const persistDir = import_node_path.default.join(dataDir, docId);
  const storageContext = await (0, import_llamaindex.storageContextFromDefaults)({ persistDir });
  const index = await import_llamaindex.VectorStoreIndex.init({ storageContext });
  const retriever = index.asRetriever({ similarityTopK: 5 });
  const nodes = await retriever.retrieve(message);
  const contextText = nodes.map((n) => n.node.text).join("\n\n");
  const prompt = `Answer the following question based on the context below.

Context:
${contextText}

Question: ${message}
Answer:`;
  const completion = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: prompt
  });
  const answer = completion.text || "No answer available.";
  return {
    text: answer,
    citations: nodes.map((n, i) => ({ page: i + 1, score: n.score }))
  };
}
async function getDocPages(docId) {
  const json = await fs.readFile(import_node_path.default.join(dataDir, docId, "pages.json"), "utf-8");
  return JSON.parse(json);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  chatAboutPdf,
  ensureIndexForDoc,
  getDocPages
});
